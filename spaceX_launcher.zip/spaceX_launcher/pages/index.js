import Fetch from 'isomorphic-unfetch';
import Layout from '../components/Layout';

const Index = (props) => (
  <Layout space={props.space} />
);

Index.getInitialProps = async function() {
  const res = await fetch('https://api.spacexdata.com/v3/launches?limit=100');
  const data = await res.json();
  return {
      space:data
    
  };
}



export default Index;