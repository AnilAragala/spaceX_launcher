
# Install dependencies
npm install

# Serve on localhost:3000
npm run dev

# Build for production
npm run build

