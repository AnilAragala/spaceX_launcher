import Head from 'next/head';
import Navbar from './Navbar';
import { useState, useEffect } from 'react'


const Layout = (props) => { 

  const [year, setYear] = useState(0);
  const [jsonData, setJsonData] = useState(props.space);
  const [searchYear] = useState([2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016,2017,2018,2019,2020]);
  const [landingValue, setLandingValue] = useState('');
  const [lanchingValue, setLaunchingValue] = useState('');

  const clickHandler = (event)=>{
    setYear(event.target.value);
  };

  const clickLaunch = (event)=>{
    setLaunchingValue(event.target.value);
  }

  const clickLanding = (event)=>{
    setLandingValue(event.target.value);
  }

  useEffect(()=>{

    // https://api.spacexdata.com/v3/launches?limit=100&launch_success=true&land_success=true&launch_year=2014

    var fullYear = year ? `&launch_year=${year}` : '';
    var launchSuc = lanchingValue !== '' ? `&launch_success=${lanchingValue}` : '';
    var landSuc = landingValue !== '' ? `&land_success=${landingValue}` : '';

    fetch(`https://api.spacexdata.com/v3/launches?limit=100${launchSuc}${landSuc}${fullYear}`)
    .then(res => res.json())
    .then(res => {setJsonData(res)})

    // if(year){
    //     fetch(`https://api.spacexdata.com/v3/launches?limit=100&launch_year=${year}`)
    //     .then(res => res.json())
    //     .then(res => {setJsonData(res)})
    //   }
    // if(lanchingValue !== "" ){
    //   fetch(`https://api.spacexdata.com/v3/launches?limit=100&launch_success=${lanchingValue}`)
    //     .then(res => res.json())
    //     .then(res => {setJsonData(res)})
    // }
    // if(landingValue !== "" ){
    //   fetch(`https://api.spacexdata.com/v3/launches?limit=100&land_success=${landingValue}`)
    //     .then(res => res.json())
    //     .then(res => {setJsonData(res)})
    // }
  },[year, lanchingValue, landingValue]);
  
 return (

 <div>
    <Head>
      <title>SpaceX</title>
      <link rel="stylesheet" href="https://bootswatch.com/4/cerulean/bootstrap.min.css"/>
    </Head>
    <Navbar/>
    <div className="container-fluid">
      <div className="row">
        <div className="col-lg-2 col-xl-2 col-md-3 col-sm-4 col-12 border border-grey" >
          <h4 style={{margin:"1px 80px", color:"#17386b"}}>Filters</h4>
          <br />
          <h5 style={{color:"black"}}>Select Year</h5>
          <div className="row" >
            {searchYear.map(yr => <div className="col-md-6 col-sm-6 col-4" key= {yr}><button type="button" className="btn btn-success btn-sm" style={{margin:"5px"}} key= {yr} value={yr} onClick={clickHandler}>{yr}</button></div>)}  
          </div>
          <br />
          <h5 style={{color:"black"}}>Launch Success</h5>
          <div className="row">
          <div className="col-md-6 col-sm-6 col-4" >
          <button type="button" className="btn btn-success btn-sm " value="true" onClick={clickLaunch}>True</button>
          </div>
          <div className="col-md-6 col-sm-6 col-4" >
          <button type="button" className="btn btn-success btn-sm " value="false" onClick={clickLaunch}>False</button>
          </div>
          </div>
          <br />
          <h5 style={{color:"black"}}>Landing Success</h5>
          <div className="row">
          <div className="col-md-6 col-sm-6 col-4" >
          <button type="button" className="btn btn-success btn-sm " value="true" onClick={clickLanding}>True</button>
          </div>
          <div className="col-md-6 col-sm-6 col-4" >
          <button type="button" className="btn btn-success btn-sm " value="false" onClick={clickLanding}>False</button>
          </div>
          </div>
        </div>
        <br />
        <div className="col-lg-10 col-xl-10 col-md-9 col-sm-8">
          <div className="row">
            { jsonData.map(fl=> <div className="col-sm-6 col-md-3 col-xl-2 col-xs-6 col-lg-3 border border-white" id="maindiv" key={fl.flight_number}> 
            <img src={fl.links.mission_patch} alt="mission" width="50%" height="auto" className="img-responsive"/>
            <span className="list-group-item" id="mission_name">{fl.mission_name}</span>
            <span className="list-group-item">Mission ids : {fl.mission_id}</span>
            <span className="list-group-item">Launch Year: {fl.launch_year}</span>
            <span className="list-group-item">Successfull Launch: {fl.launch_success ? "true" : "false"}</span>
            <span className="list-group-item">Successfull Landing: {fl.rocket.first_stage.cores[0].land_success ? "true" :  'false' }</span>
            </div>)}
          </div>
        </div>
      </div>
      </div>
      <style jsx global>
            {` 
            #maindiv {
              background: #dedede;
            }
            img {
              display: block;
              margin-left: auto;
              margin-right: auto;
              background-color : light-grey;
            }

            #mission_name {
              display : block;
              text-align : center;
              color : blue
            }
            
            `} 
          </style>
  </div>
  )};

export default Layout;