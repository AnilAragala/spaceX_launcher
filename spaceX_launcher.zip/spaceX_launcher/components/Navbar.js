import Link from 'next/link';

const Navbar = () => (
  <nav className="navbar navbar-expand navbar-dark bg-dark mb-4">
    <div className="container">
      <a className="navbar-brand" href="#"><h1 >SpaceX Launch Program</h1></a>
    </div>
    
  </nav>
);

export default Navbar;